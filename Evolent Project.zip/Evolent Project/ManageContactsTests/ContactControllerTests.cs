using ManageContacts.Controllers;
using ManageContacts.Models;
using ManageContacts.Repository;
using ManageContacts.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace ManageContactsTests
{
    public class ContactControllerTests
    {
        private readonly Mock<ILogger<ContactController>> _mockLogger;

        private readonly Mock<IContactRepository> _mockContactRepository;

        private readonly Lazy<ILogger<ContactController>> _lazyLogger;

        private readonly Lazy<IContactRepository> _lazyContactRepository;

        public ContactControllerTests()
        {
            _mockLogger = new Mock<ILogger<ContactController>>();
            _mockContactRepository = new Mock<IContactRepository>();

            _lazyLogger = new Lazy<ILogger<ContactController>>(() => _mockLogger.Object);
            _lazyContactRepository = new Lazy<IContactRepository>(() => _mockContactRepository.Object);
        }

        [Fact]
        public async Task GetContactsAsync_Returns_NotFound()
        {
            using var contactController = NewConstructor(
                _lazyLogger,
                _lazyContactRepository);

            var response = await contactController.GetContactsAsync();

            var notFoundResult = Assert.IsType<NotFoundResult>(response);
            Assert.Equal(StatusCodes.Status404NotFound, notFoundResult.StatusCode);
        }

        [Fact]
        public async Task GetContactsAsync_Returns_Ok()
        {
            var contactViewModels = new List<ContactViewModel>
            {
                new ContactViewModel{
                    ContactId= 1,
                    FirstName= "Salman",
                    LastName= "Khan",
                    Email= "salmankhan@gmil.com",
                    PhoneNumber= "9898989898",
                    Status= true
                    },
                new ContactViewModel{
                    ContactId= 2,
                    FirstName= "Harry",
                    LastName= "Potter",
                    Email= "harrypotter@gmail.com",
                    PhoneNumber= "9876543210",
                    Status= true
                }
            };

            _mockContactRepository.Reset();
            _mockContactRepository.Setup(m => m.GetContacts())
                .ReturnsAsync(new List<ContactViewModel>
                {
                    new ContactViewModel{
                        ContactId= 1,
                        FirstName= "Salman",
                        LastName= "Khan",
                        Email= "salmankhan@gmil.com",
                        PhoneNumber= "9898989898",
                        Status= true
                    },
                    new ContactViewModel{
                        ContactId= 2,
                        FirstName= "Harry",
                        LastName= "Potter",
                        Email= "harrypotter@gmail.com",
                        PhoneNumber= "9876543210",
                        Status= true
                    }
                });

            using var contactController = NewConstructor(
                _lazyLogger,
                _lazyContactRepository);

            var response = await contactController.GetContactsAsync();

            var okObjectResult = Assert.IsType<OkObjectResult>(response);
            var result = Assert.IsType<List<ContactViewModel>>(okObjectResult.Value);

            Assert.Equal(contactViewModels.Count, result.Count);
            for (int i = 0; i < contactViewModels.Count; i++)
            {
                Assert.True(ContactViewModelsAreEqual(contactViewModels[i], result[i]));
            }
        }

        //TODO: Need to cover runtime scenario like real time modification in collection
        [Fact]
        public async Task AddContactAsync_Returns_Ok()
        {
            var contactViewModel = new Contact
            {
                FirstName = "Salman",
                LastName = "Khan",
                Email = "salmankhan@gmil.com",
                PhoneNumber = "9898989898",
                Status = true
            };

            var contactModel = new Contact{
                    ContactId= 1,
                    FirstName= "Salman",
                    LastName= "Khan",
                    Email= "salmankhan@gmil.com",
                    PhoneNumber= "9898989898",
                    Status= true
            };

            _mockContactRepository.Reset();
            _mockContactRepository.Setup(m => m.AddContact(contactViewModel))
                .ReturnsAsync(1);

            using var contactController = NewConstructor(
                _lazyLogger,
                _lazyContactRepository);

            var response = await contactController.AddContactAsync(contactViewModel);

            var okObjectResult = Assert.IsType<OkObjectResult>(response);
            var result = Assert.IsType<long>(okObjectResult.Value);

            Assert.Equal(contactModel.ContactId, result);
        }

        //TODO: Need to cover runtime scenario like real time modification in collection
        [Fact]
        public async Task DeleteContactAsync_Returns_Ok()
        {
            _mockContactRepository.Reset();
            _mockContactRepository.Setup(m => m.DeleteContact(1))
                .ReturnsAsync(1);

            using var contactController = NewConstructor(
                _lazyLogger,
                _lazyContactRepository);

            var response = await contactController.DeleteContactAsync(1);

            var okResult = Assert.IsType<OkResult>(response);
            var result = Assert.IsType<OkResult>(okResult);

            Assert.Equal(StatusCodes.Status200OK, result.StatusCode);
        }

        private static ContactController NewConstructor(
            Lazy<ILogger<ContactController>> logger,
            Lazy<IContactRepository> contactRepository)
        {
            var httpContext = new DefaultHttpContext();
            var controllerContext = new ControllerContext
            {
                HttpContext = httpContext,
            };
            var controller = new ContactController(
                contactRepository,
                logger)
            {
                ControllerContext = controllerContext
            };

            return controller;
        }

        private static bool ContactViewModelsAreEqual(ContactViewModel modelOriginal, ContactViewModel model)
        {
            return modelOriginal.ContactId == model.ContactId &&
                modelOriginal.FirstName == model.FirstName &&
                modelOriginal.LastName == model.LastName &&
                modelOriginal.PhoneNumber == model.PhoneNumber &&
                modelOriginal.Status == model.Status;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using ManageContacts.Helpers;
using ManageContacts.Models;
using ManageContacts.Repository;
using ManageContacts.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ManageContacts.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public sealed class ContactController : Controller
    {
        private readonly Lazy<ILogger<ContactController>> _logger;

        private readonly Lazy<IContactRepository> _contactRepository;
        public ContactController(Lazy<IContactRepository> contactRepository, Lazy<ILogger<ContactController>> logger)
        {
            _contactRepository = contactRepository;
            _logger = logger;
        }

        [HttpGet]
        [Route("GetContacts")]
        public async Task<IActionResult> GetContactsAsync()
        {
            _logger.Value.LogInformation($"Called {GetType().Name}.{MethodBase.GetCurrentMethod().Name}");

            try
            {
                var contacts = await _contactRepository.Value.GetContacts();
                if (contacts == null)
                {
                    return NotFound();
                }

                return Ok(contacts);
            }
            catch (Exception ex)
            {
                _logger.Value.LogError($"{GetType().Name}.{MethodBase.GetCurrentMethod().Name}", ex.Message);

                return BadRequest();
            }
        }

        [HttpPost]
        [Route("AddContact")]
        public async Task<IActionResult> AddContactAsync([FromBody] Contact model)
        {
            _logger.Value.LogInformation($"Called {GetType().Name}.{MethodBase.GetCurrentMethod().Name}");

            if (ModelState.IsValid)
            {
                try
                {
                    var contactId = await _contactRepository.Value.AddContact(model);
                    if (contactId > 0)
                    {
                        return Ok(contactId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception ex)
                {
                    _logger.Value.LogError($"{GetType().Name}.{MethodBase.GetCurrentMethod().Name}", ex.Message);

                    return BadRequest();
                }

            }

            return BadRequest();
        }

        [HttpDelete]
        [Route("DeleteContact")]
        public async Task<IActionResult> DeleteContactAsync(long contactId)
        {
            _logger.Value.LogInformation($"Called {GetType().Name}.{MethodBase.GetCurrentMethod().Name}");

            try
            {
                int result = await _contactRepository.Value.DeleteContact(contactId);
                if (result == 0)
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception ex)
            {
                _logger.Value.LogError($"{GetType().Name}.{MethodBase.GetCurrentMethod().Name}", ex.Message);

                return BadRequest();
            }
        }

        [HttpPut]
        [Route("UpdateContact")]
        public async Task<IActionResult> UpdateContactAsync([FromBody] Contact model)
        {
            _logger.Value.LogInformation($"Called {GetType().Name}.{MethodBase.GetCurrentMethod().Name}");

            if (ModelState.IsValid)
            {
                try
                {
                    await _contactRepository.Value.UpdateContact(model);

                    return Ok();
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    _logger.Value.LogError($"{GetType().Name}.{MethodBase.GetCurrentMethod().Name}", ex.Message);


                    return BadRequest();
                }
            }

            return BadRequest();
        }
    }
}

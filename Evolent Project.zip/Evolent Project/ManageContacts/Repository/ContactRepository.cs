﻿using ManageContacts.Models;
using ManageContacts.ViewModel;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ManageContacts.Repository
{
    public class ContactRepository : IContactRepository
    {
        TestContext db;
        public ContactRepository(TestContext _db)
        {
            db = _db;
        }

        public async Task<long> AddContact(Contact contact)
        {
            if (db != null)
            {
                await db.Contacts.AddAsync(contact);
                await db.SaveChangesAsync();

                return contact.ContactId ?? 0;
            }

            return 0;
        }

        public async Task<int> DeleteContact(long contactId)
        {
            int result = 0;

            if (db != null)
            {
                //Find the contact for specific contact id
                var contact = await db.Contacts.FirstOrDefaultAsync(x => x.ContactId == contactId);

                if (contact != null)
                {
                    contact.Status = false;

                    //Delete that contact
                    db.Contacts.Update(contact);

                    //Commit the transaction
                    result = await db.SaveChangesAsync();
                }
                return result;
            }

            return result;
        }

        public async Task<List<ContactViewModel>> GetContacts()
        {
            if (db != null)
            {
                return await (from p in db.Contacts
                              select new ContactViewModel
                              {
                                  ContactId = p.ContactId.Value,
                                  FirstName = p.FirstName,
                                  LastName = p.LastName,
                                  Email = p.Email,
                                  PhoneNumber = p.PhoneNumber,
                                  Status = p.Status
                              }).ToListAsync();
            }

            return null;
        }

        public async Task UpdateContact(Contact contact)
        {
            if (db != null)
            {
                //Update that contact
                db.Contacts.Update(contact);

                //Commit the transaction
                await db.SaveChangesAsync();
            }
        }
    }
}

﻿using ManageContacts.Models;
using ManageContacts.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ManageContacts.Repository
{
    public interface IContactRepository
    {
        Task<List<ContactViewModel>> GetContacts();

        Task<long> AddContact(Contact contact);

        Task<int> DeleteContact(long contactId);

        Task UpdateContact(Contact contact);
    }
}

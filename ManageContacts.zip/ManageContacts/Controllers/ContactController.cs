﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ManageContacts.Models;
using ManageContacts.Repository;
using ManageContacts.ViewModel;
using Microsoft.AspNetCore.Mvc;

namespace ManageContacts.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        IContactRepository contactRepository;
        public ContactController(IContactRepository _contactRepository)
        {
            contactRepository = _contactRepository;
        }

        [HttpGet]
        [Route("GetContacts")]
        public async Task<IActionResult> GetContacts()
        {
            try
            {
                var contacts = await contactRepository.GetContacts();
                if (contacts == null)
                {
                    return NotFound();
                }

                return Ok(contacts);
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPost]
        [Route("AddContact")]
        public async Task<IActionResult> AddContact([FromBody] Contact model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var contactId = await contactRepository.AddContact(model);
                    if (contactId > 0)
                    {
                        return Ok(contactId);
                    }
                    else
                    {
                        return NotFound();
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest();
                }

            }

            return BadRequest();
        }

        [HttpDelete]
        [Route("DeleteContact")]
        public async Task<IActionResult> DeleteContact(long contactId)
        {
            try
            {
                int result = await contactRepository.DeleteContact(contactId);
                if (result == 0)
                {
                    return NotFound();
                }
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest();
            }
        }

        [HttpPut]
        [Route("UpdateContact")]
        public async Task<IActionResult> UpdateContact([FromBody] Contact model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    await contactRepository.UpdateContact(model);

                    return Ok();
                }
                catch (Exception ex)
                {
                    if (ex.GetType().FullName == "Microsoft.EntityFrameworkCore.DbUpdateConcurrencyException")
                    {
                        return NotFound();
                    }

                    return BadRequest();
                }
            }

            return BadRequest();
        }
    }
}
